<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


// Base path. URLs will be /path_base/path_<asset type>/<asset_name>
$config['path_base'] 		    = 'assets';
// Read above. Path for asset types.
$config['path_js'] 		    = 'js';
$config['path_css'] 	            = 'css';
$config['path_img'] 		    = 'img';

